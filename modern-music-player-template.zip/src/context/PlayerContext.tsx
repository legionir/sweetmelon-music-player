import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { RepeatMode, Track } from "../types";
import { libraryService } from "../data/mockLibrary";

/**
 * -----------------------------------------------------------------------
 * PLAYER CONTEXT — the single source of truth for playback.
 * -----------------------------------------------------------------------
 * Every control in the UI (explorer rows, player bar, now-playing screen)
 * reads/writes through this context instead of touching an <audio>
 * element directly. That makes it trivial to later swap the underlying
 * engine (e.g. native mobile player, Web Audio graph, streaming SDK)
 * without rewriting any component — just reimplement this provider.
 * -----------------------------------------------------------------------
 */

interface PlayerContextValue {
  queue: Track[];
  originalQueue: Track[];
  currentTrack: Track | null;
  currentIndex: number;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  isLoading: boolean;
  /** Replaces the queue and starts playing a track (defaults to first item). */
  playQueue: (tracks: Track[], startIndex?: number) => void;
  /** Plays a single track, appending it as a 1-item queue unless it's already in queue. */
  playTrack: (track: Track, contextTracks?: Track[]) => void;
  togglePlay: () => void;
  pause: () => void;
  next: () => void;
  previous: () => void;
  seek: (time: number) => void;
  setVolume: (value: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  cycleRepeat: () => void;
  toggleLike: (trackId: string) => void;
  addToQueue: (track: Track) => void;
  removeFromQueue: (index: number) => void;
}

const PlayerContext = createContext<PlayerContextValue | null>(null);

function shuffleArray<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export function PlayerProvider({ children }: { children: ReactNode }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  if (!audioRef.current && typeof window !== "undefined") {
    audioRef.current = new Audio();
  }

  const [originalQueue, setOriginalQueue] = useState<Track[]>([]);
  const [queue, setQueue] = useState<Track[]>([]);
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(0.8);
  const [muted, setMuted] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<RepeatMode>("off");
  const [isLoading, setIsLoading] = useState(false);

  const currentTrack = currentIndex >= 0 ? queue[currentIndex] ?? null : null;

  // Keep <audio> element in sync with the active track.
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !currentTrack) return;
    if (audio.src !== currentTrack.src) {
      setIsLoading(true);
      audio.src = currentTrack.src;
      audio.load();
      if (isPlaying) {
        audio.play().catch(() => setIsPlaying(false));
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentTrack?.id]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTimeUpdate = () => setCurrentTime(audio.currentTime);
    const onLoadedMetadata = () => {
      setDuration(audio.duration || 0);
      setIsLoading(false);
    };
    const onCanPlay = () => setIsLoading(false);
    const onEnded = () => handleTrackEnd();
    const onWaiting = () => setIsLoading(true);
    const onPlaying = () => setIsLoading(false);

    audio.addEventListener("timeupdate", onTimeUpdate);
    audio.addEventListener("loadedmetadata", onLoadedMetadata);
    audio.addEventListener("canplay", onCanPlay);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("waiting", onWaiting);
    audio.addEventListener("playing", onPlaying);

    return () => {
      audio.removeEventListener("timeupdate", onTimeUpdate);
      audio.removeEventListener("loadedmetadata", onLoadedMetadata);
      audio.removeEventListener("canplay", onCanPlay);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("waiting", onWaiting);
      audio.removeEventListener("playing", onPlaying);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [queue, currentIndex, repeat, shuffle]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.volume = muted ? 0 : volume;
  }, [volume, muted]);

  function handleTrackEnd() {
    const audio = audioRef.current;

    if (repeat === "one") {
      if (audio) {
        audio.currentTime = 0;
        audio.play().catch(() => {});
      }
      return;
    }

    setCurrentIndex((idx) => {
      const isLast = idx >= queue.length - 1;
      if (isLast) {
        if (repeat === "all") return 0;
        setIsPlaying(false);
        return idx;
      }
      return idx + 1;
    });
  }

  const playQueue = useCallback((tracks: Track[], startIndex = 0) => {
    setOriginalQueue(tracks);
    const list = shuffle ? shuffleArray(tracks) : tracks;
    setQueue(list);
    const startTrack = tracks[startIndex];
    const idx = shuffle ? list.findIndex((t) => t.id === startTrack?.id) : startIndex;
    setCurrentIndex(idx);
    setIsPlaying(true);
  }, [shuffle]);

  const playTrack = useCallback((track: Track, contextTracks?: Track[]) => {
    const list = contextTracks && contextTracks.length > 0 ? contextTracks : [track];
    const idx = list.findIndex((t) => t.id === track.id);
    playQueue(list, idx >= 0 ? idx : 0);
  }, [playQueue]);

  const togglePlay = useCallback(() => {
    const audio = audioRef.current;
    if (!audio || !currentTrack) return;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().catch(() => {});
      setIsPlaying(true);
    }
  }, [isPlaying, currentTrack]);

  const pause = useCallback(() => {
    audioRef.current?.pause();
    setIsPlaying(false);
  }, []);

  const next = useCallback(() => {
    setCurrentIndex((idx) => {
      if (queue.length === 0) return idx;
      if (idx >= queue.length - 1) {
        return repeat === "all" ? 0 : idx;
      }
      return idx + 1;
    });
    setIsPlaying(true);
  }, [queue.length, repeat]);

  const previous = useCallback(() => {
    const audio = audioRef.current;
    if (audio && audio.currentTime > 3) {
      audio.currentTime = 0;
      return;
    }
    setCurrentIndex((idx) => {
      if (idx <= 0) return repeat === "all" ? queue.length - 1 : 0;
      return idx - 1;
    });
    setIsPlaying(true);
  }, [queue.length, repeat]);

  const seek = useCallback((time: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.currentTime = time;
    setCurrentTime(time);
  }, []);

  const setVolume = useCallback((value: number) => {
    setVolumeState(Math.min(1, Math.max(0, value)));
    if (value > 0) setMuted(false);
  }, []);

  const toggleMute = useCallback(() => setMuted((m) => !m), []);

  const toggleShuffle = useCallback(() => {
    setShuffle((prev) => {
      const next = !prev;
      setQueue((currentQueue) => {
        const active = currentQueue[currentIndex];
        if (next) {
          const shuffled = shuffleArray(originalQueue.length ? originalQueue : currentQueue);
          const newIdx = shuffled.findIndex((t) => t.id === active?.id);
          setCurrentIndex(newIdx >= 0 ? newIdx : 0);
          return shuffled;
        } else {
          const restored = originalQueue.length ? originalQueue : currentQueue;
          const newIdx = restored.findIndex((t) => t.id === active?.id);
          setCurrentIndex(newIdx >= 0 ? newIdx : 0);
          return restored;
        }
      });
      return next;
    });
  }, [currentIndex, originalQueue]);

  const cycleRepeat = useCallback(() => {
    setRepeat((prev) => (prev === "off" ? "all" : prev === "all" ? "one" : "off"));
  }, []);

  const toggleLike = useCallback((trackId: string) => {
    libraryService.toggleLike(trackId).then((updated) => {
      setQueue((q) => q.map((t) => (t.id === updated.id ? { ...updated } : t)));
      setOriginalQueue((q) => q.map((t) => (t.id === updated.id ? { ...updated } : t)));
    });
  }, []);

  const addToQueue = useCallback((track: Track) => {
    setQueue((q) => [...q, track]);
    setOriginalQueue((q) => [...q, track]);
  }, []);

  const removeFromQueue = useCallback((index: number) => {
    setQueue((q) => q.filter((_, i) => i !== index));
    setCurrentIndex((idx) => (index < idx ? idx - 1 : idx));
  }, []);

  const value = useMemo<PlayerContextValue>(
    () => ({
      queue,
      originalQueue,
      currentTrack,
      currentIndex,
      isPlaying,
      currentTime,
      duration,
      volume,
      muted,
      shuffle,
      repeat,
      isLoading,
      playQueue,
      playTrack,
      togglePlay,
      pause,
      next,
      previous,
      seek,
      setVolume,
      toggleMute,
      toggleShuffle,
      cycleRepeat,
      toggleLike,
      addToQueue,
      removeFromQueue,
    }),
    [
      queue,
      originalQueue,
      currentTrack,
      currentIndex,
      isPlaying,
      currentTime,
      duration,
      volume,
      muted,
      shuffle,
      repeat,
      isLoading,
      playQueue,
      playTrack,
      togglePlay,
      pause,
      next,
      previous,
      seek,
      setVolume,
      toggleMute,
      toggleShuffle,
      cycleRepeat,
      toggleLike,
      addToQueue,
      removeFromQueue,
    ],
  );

  return <PlayerContext.Provider value={value}>{children}</PlayerContext.Provider>;
}

export function usePlayer() {
  const ctx = useContext(PlayerContext);
  if (!ctx) throw new Error("usePlayer must be used within a PlayerProvider");
  return ctx;
}
