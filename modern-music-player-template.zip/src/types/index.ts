/**
 * Core domain types for the music player.
 *
 * These interfaces are intentionally decoupled from any specific data
 * source. Today they're backed by `src/data/mockLibrary.ts`, but the same
 * shapes can be returned by a real REST/GraphQL API or a native file
 * system bridge (Electron/Tauri) without touching the UI layer.
 */

export type RepeatMode = "off" | "all" | "one";

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  genre: string;
  /** Duration in seconds. Can be a fallback estimate until real metadata loads. */
  duration: number;
  /** Playable audio source URL. In production this could be a signed URL, blob, or local path. */
  src: string;
  /** Square cover artwork URL. */
  cover: string;
  /** ISO date string representing when the file was added to the library. */
  addedAt: string;
  liked: boolean;
  /** Id of the parent folder this track lives in. */
  folderId: string;
}

export type FileSystemNodeType = "folder" | "track";

export interface FolderNode {
  id: string;
  type: "folder";
  name: string;
  parentId: string | null;
  /** Optional icon hint used by the explorer UI. */
  kind?: "root" | "playlist" | "genre" | "smart" | "default";
  description?: string;
}

export type ExplorerEntry =
  | (FolderNode & { type: "folder" })
  | (Track & { type: "track" });

export interface PlayerState {
  queue: Track[];
  currentIndex: number;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
}
