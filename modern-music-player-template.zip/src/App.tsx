import { HashRouter, Routes, Route } from "react-router-dom";
import { PlayerProvider } from "./context/PlayerContext";
import { Sidebar } from "./components/Sidebar";
import { MobileNav } from "./components/MobileNav";
import { PlayerBar } from "./components/PlayerBar";
import { Explorer } from "./pages/Explorer";
import { NowPlaying } from "./pages/NowPlaying";

export default function App() {
  return (
    <PlayerProvider>
      <HashRouter>
        <div className="min-h-screen bg-[#07070d] text-white antialiased">
          <div className="flex min-h-screen">
            <Sidebar />
            <div className="flex min-w-0 flex-1 flex-col">
              <MobileNav />
              <main className="flex-1 pb-24">
                <Routes>
                  <Route path="/" element={<Explorer />} />
                  <Route path="/now-playing" element={<NowPlaying />} />
                </Routes>
              </main>
            </div>
          </div>
          <PlayerBar />
        </div>
      </HashRouter>
    </PlayerProvider>
  );
}
