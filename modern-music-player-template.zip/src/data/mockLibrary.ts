import type { FolderNode, Track } from "../types";

/**
 * -----------------------------------------------------------------------
 * MOCK DATA SOURCE
 * -----------------------------------------------------------------------
 * This file stands in for a real backend / file system. Everything below
 * is exposed through the `libraryService` object at the bottom, which is
 * the ONLY thing the rest of the app talks to.
 *
 * To connect this app to a real source later, create a new file (e.g.
 * `realLibrary.ts`) that implements the same `LibraryService` interface
 * and swap the export in `src/data/index.ts`. No UI code needs to change.
 * -----------------------------------------------------------------------
 */

export const folders: FolderNode[] = [
  { id: "root", type: "folder", name: "Library", parentId: null, kind: "root" },
  { id: "recent", type: "folder", name: "Recently Added", parentId: "root", kind: "smart", description: "Freshly imported tracks" },
  { id: "favorites", type: "folder", name: "Favorites", parentId: "root", kind: "smart", description: "Tracks you've liked" },
  { id: "playlists", type: "folder", name: "Playlists", parentId: "root", kind: "default" },
  { id: "pl-chill", type: "folder", name: "Chill Vibes", parentId: "playlists", kind: "playlist", description: "Laid-back evening sounds" },
  { id: "pl-workout", type: "folder", name: "Workout Mix", parentId: "playlists", kind: "playlist", description: "High energy training set" },
  { id: "pl-focus", type: "folder", name: "Focus Flow", parentId: "playlists", kind: "playlist", description: "Deep work soundtrack" },
  { id: "genres", type: "folder", name: "Genres", parentId: "root", kind: "default" },
  { id: "g-synthwave", type: "folder", name: "Synthwave", parentId: "genres", kind: "genre" },
  { id: "g-lofi", type: "folder", name: "Lo-fi", parentId: "genres", kind: "genre" },
  { id: "g-ambient", type: "folder", name: "Ambient", parentId: "genres", kind: "genre" },
];

const SOUNDHELIX = (n: number) =>
  `https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${n}.mp3`;

export const tracks: Track[] = [
  {
    id: "t1",
    title: "Neon Horizon",
    artist: "Nova Drift",
    album: "Night Signals",
    genre: "Synthwave",
    duration: 245,
    src: SOUNDHELIX(1),
    cover: "/images/cover-synthwave.jpg",
    addedAt: "2026-01-14",
    liked: true,
    folderId: "g-synthwave",
  },
  {
    id: "t2",
    title: "Chrome Avenue",
    artist: "Nova Drift",
    album: "Night Signals",
    genre: "Synthwave",
    duration: 268,
    src: SOUNDHELIX(2),
    cover: "/images/cover-synthwave.jpg",
    addedAt: "2026-01-20",
    liked: false,
    folderId: "g-synthwave",
  },
  {
    id: "t3",
    title: "Rainy Window",
    artist: "Mellow Hours",
    album: "Study Sessions",
    genre: "Lo-fi",
    duration: 192,
    src: SOUNDHELIX(3),
    cover: "/images/cover-lofi.jpg",
    addedAt: "2026-02-02",
    liked: true,
    folderId: "g-lofi",
  },
  {
    id: "t4",
    title: "Turntable Dust",
    artist: "Mellow Hours",
    album: "Study Sessions",
    genre: "Lo-fi",
    duration: 211,
    src: SOUNDHELIX(4),
    cover: "/images/cover-lofi.jpg",
    addedAt: "2026-02-10",
    liked: false,
    folderId: "g-lofi",
  },
  {
    id: "t5",
    title: "Drifting Nebula",
    artist: "Quiet Orbit",
    album: "Interstellar Calm",
    genre: "Ambient",
    duration: 301,
    src: SOUNDHELIX(5),
    cover: "/images/cover-ambient.jpg",
    addedAt: "2026-02-18",
    liked: false,
    folderId: "g-ambient",
  },
  {
    id: "t6",
    title: "Stardust Drip",
    artist: "Quiet Orbit",
    album: "Interstellar Calm",
    genre: "Ambient",
    duration: 278,
    src: SOUNDHELIX(6),
    cover: "/images/cover-ambient.jpg",
    addedAt: "2026-02-22",
    liked: true,
    folderId: "g-ambient",
  },
  {
    id: "t7",
    title: "Golden Shoreline",
    artist: "Coastal Haze",
    album: "Low Tide",
    genre: "Chillwave",
    duration: 223,
    src: SOUNDHELIX(7),
    cover: "/images/cover-chill.jpg",
    addedAt: "2026-03-01",
    liked: false,
    folderId: "pl-chill",
  },
  {
    id: "t8",
    title: "Palm Shade",
    artist: "Coastal Haze",
    album: "Low Tide",
    genre: "Chillwave",
    duration: 199,
    src: SOUNDHELIX(8),
    cover: "/images/cover-chill.jpg",
    addedAt: "2026-03-05",
    liked: false,
    folderId: "pl-chill",
  },
  {
    id: "t9",
    title: "Overdrive Pulse",
    artist: "Kinetic Rush",
    album: "Redline",
    genre: "Electronic",
    duration: 234,
    src: SOUNDHELIX(9),
    cover: "/images/cover-workout.jpg",
    addedAt: "2026-03-08",
    liked: true,
    folderId: "pl-workout",
  },
  {
    id: "t10",
    title: "Iron Momentum",
    artist: "Kinetic Rush",
    album: "Redline",
    genre: "Electronic",
    duration: 256,
    src: SOUNDHELIX(10),
    cover: "/images/cover-workout.jpg",
    addedAt: "2026-03-11",
    liked: false,
    folderId: "pl-workout",
  },
  {
    id: "t11",
    title: "Clarity Stream",
    artist: "Silent Pace",
    album: "Deep Work",
    genre: "Minimal",
    duration: 287,
    src: SOUNDHELIX(11),
    cover: "/images/cover-focus.jpg",
    addedAt: "2026-03-14",
    liked: false,
    folderId: "pl-focus",
  },
  {
    id: "t12",
    title: "Quiet Mind",
    artist: "Silent Pace",
    album: "Deep Work",
    genre: "Minimal",
    duration: 264,
    src: SOUNDHELIX(13),
    cover: "/images/cover-focus.jpg",
    addedAt: "2026-03-19",
    liked: true,
    folderId: "pl-focus",
  },
];

function simulateLatency<T>(value: T): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), 120));
}

export interface LibraryService {
  getFolders(): Promise<FolderNode[]>;
  getAllTracks(): Promise<Track[]>;
  /** Returns the folders + tracks that live directly inside a given folder id. */
  getFolderContents(folderId: string): Promise<{ folders: FolderNode[]; tracks: Track[] }>;
  getFolderPath(folderId: string): Promise<FolderNode[]>;
  searchTracks(query: string): Promise<Track[]>;
  toggleLike(trackId: string): Promise<Track>;
}

export const libraryService: LibraryService = {
  async getFolders() {
    return simulateLatency(folders);
  },

  async getAllTracks() {
    return simulateLatency(tracks);
  },

  async getFolderContents(folderId: string) {
    if (folderId === "recent") {
      const sorted = [...tracks].sort(
        (a, b) => new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime(),
      );
      return simulateLatency({ folders: [], tracks: sorted });
    }
    if (folderId === "favorites") {
      return simulateLatency({ folders: [], tracks: tracks.filter((t) => t.liked) });
    }
    const childFolders = folders.filter((f) => f.parentId === folderId);
    const childTracks = tracks.filter((t) => t.folderId === folderId);
    return simulateLatency({ folders: childFolders, tracks: childTracks });
  },

  async getFolderPath(folderId: string) {
    const path: FolderNode[] = [];
    let current = folders.find((f) => f.id === folderId) ?? null;
    while (current) {
      path.unshift(current);
      current = current.parentId ? folders.find((f) => f.id === current!.parentId) ?? null : null;
    }
    return simulateLatency(path);
  },

  async searchTracks(query: string) {
    const q = query.trim().toLowerCase();
    if (!q) return simulateLatency([]);
    return simulateLatency(
      tracks.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          t.artist.toLowerCase().includes(q) ||
          t.album.toLowerCase().includes(q) ||
          t.genre.toLowerCase().includes(q),
      ),
    );
  },

  async toggleLike(trackId: string) {
    const track = tracks.find((t) => t.id === trackId);
    if (!track) throw new Error(`Track ${trackId} not found`);
    track.liked = !track.liked;
    return simulateLatency(track);
  },
};
